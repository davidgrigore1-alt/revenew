@echo off
cd /d C:\Projects\ReveNew
powershell -NoProfile -ExecutionPolicy Bypass -File ".\ReveNew-ControlCenter-Polish-v4.2\rollback.ps1"
